<?php
session_start();
ob_start();
$array = [];

if(isset($_SESSION["array"])){
    $array = json_decode(base64_decode(urldecode($_SESSION["array"])), true);
}

?>
<form action="../API/search.php" method="GET">
    <input class="input-group input-group-lg mt-3" type="text" name="name" placeholder="Rechercher ..." 
    id="searchBox" >
    <input type="submit" name="submit" value="search">
</form>

<table class="table">
    <thead>
        <tr>
            <th>Id</th>            
            <th>Prenom</th>
            <th>Nom</th>
            <th>Rue</th>
            <th>Ville</th>
            <th>Code Postale</th>
        </tr>
    </thead>
    <?php if($array != []) {
        foreach ($array as $client) : ?>
            <tr>
                <td><?php echo $client['guid'];; ?></td>
                <td><?php echo $client['first']; ?></td>
                <td><?php echo $client['last']; ?></td>
                <td><?php echo $client['street']; ?></td>
                <td><?php echo $client['city']; ?></td>
                <td><?php echo $client['zip']; ?></td>
            </tr>
    <?php endforeach;} ?>
</table>

<?php
$content = ob_get_clean();
require_once("template.php");