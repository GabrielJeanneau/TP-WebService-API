<?php
ob_start();
?>
<h1 class="mt-3">Bienvenue sur un site qui liste les Clients</h1>
<?php
$content = ob_get_clean();
require_once("template.php");