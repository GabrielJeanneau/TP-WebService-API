<?php 
define("URL", str_replace("index.php","",(isset($_SERVER['HTTPS'])? "https" : "http").
"://".$_SERVER['HTTP_HOST'].$_SERVER["PHP_SELF"]));

function getClients($name){
    $pdo = getConnexion();
    $req = "SELECT * FROM `clients` WHERE guid LIKE :name or first LIKE :name or last LIKE :name or street LIKE :name or city LIKE :name or zip LIKE :name";
    $stmt = $pdo->prepare($req);
    $stmt->execute(["name" => "%" . $name . "%"]);
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $clients;
}

function getConnexion(){
    return new PDO("mysql:host=localhost;dbname=serviceweb;charset=utf8","root","");
}

function sendJSON($infos){
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json");
    echo json_encode($infos,JSON_UNESCAPED_UNICODE);
}