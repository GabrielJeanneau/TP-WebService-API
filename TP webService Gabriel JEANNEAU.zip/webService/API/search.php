<?php
session_start();

require './api.php';

$name = $_GET['name'];
$clients = getClients($name);

if ($clients!= ""){
    $_SESSION["array"] = urlencode(base64_encode(json_encode($clients)));
        header("Location: ../APP/clients.php");

} else {
    echo ("Faites une recherche");
};